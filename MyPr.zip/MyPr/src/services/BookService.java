package services;
import models.Book;
import java.io.IOException;
import java.util.List;
public interface BookService {
    void save(Book book) throws IOException;
    void delete(Long id) throws IOException;
    List<String> getAllBooks();
    List<Book> getAllBooks_All();
   Book findBook(String name);

}
