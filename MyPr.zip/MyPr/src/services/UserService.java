package services;
public interface UserService {
    String getAll(String username,String pass);
}
