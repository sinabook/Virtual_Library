import models.*;

import java.io.FileWriter;
import java.io.IOException;
import java.util.Date;
import java.util.List;
import java.util.Random;
import java.util.Scanner;

public class Main {

public static String current_user;
public static String current_pass;
public static String current_mode;


    public static void main(String[] args) throws IOException {
        handleLogs();
    }

    private static void handleLogs() throws IOException {
        Scanner scanner=new Scanner(System.in);
        System.out.println("1-Log_in");
        System.out.println("2-Sign_in");
        int h=scanner.nextInt();
        if(h==1){
            login();
            if(current_mode!=null){
                if(current_mode.equals("0")){//0=modir
                menuModir();
                }else if(current_mode.equals("1")){//1=user
                    menuUser();
                }
            }
        }else if(h==2){
            Signin();
            menuUser();
        }
    }


    static void menuModir() throws IOException {
        while (true){
            Scanner scanner=new Scanner(System.in);
            System.out.println("Enter a number to continue:");
            System.out.println("1-Add a new book");
            System.out.println("2-Delete a book");
            System.out.println("3-Show books list");
            System.out.println("4-Find a book");
            System.out.println("5-Exit");
            
            int h=scanner.nextInt();
            if(h==1){
                add_Book();
            }else if(h==2){
                delete_Book();
            }
            else if(h==3){
                Book book=new Book();
                List<String>list=book.getAllBooks();
                for (int i = 0; i < list.size(); i++) {
                    System.out.println(list.get(i));
                }
            }
            else if(h==4){
                System.out.println("Enter a name");
                String nm=scanner.next();
                Book book=new Book();
                book=book.findBook(nm);
                if(!book.getBook().equals("")){
                    System.out.println("Books Id:"+book.getId());
                    System.out.println("Books Name"+book.getBook());
                    System.out.println("Books Author:"+book.getAuthor());
                    System.out.println("Books Publisher"+book.getNasher());
                }

            }
            else if(h==5){
                break;
            }
            else {
                System.out.println("wrong input");
            }
        }

    }
    private static void delete_Book() throws IOException {
        Book book=new Book();
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter Books Id to be deleted");
        book.delete((long) scanner.nextInt());
        System.out.println("Deleted successfully");
    }


    static void menuUser() throws IOException {
        Scanner scanner=new Scanner(System.in);
        while (true){
            System.out.println("Enter a number to continue:");
            System.out.println("1-Show books list");
            System.out.println("2-Find a book");
            System.out.println("3-Add a book");
            System.out.println("4-Show amant lists");
            System.out.println("5-Exit");
            int h=scanner.nextInt();
            if(h==1){
                Book book=new Book();
                List<String>list=book.getAllBooks();
                for (int i = 0; i < list.size(); i++) {
                    System.out.println(list.get(i));
                }
                System.out.println("To borrow a book please enter its name:");
                String namebook=scanner.next();
                book=book.findBook(namebook);
                book.setAmanat(true);
                Date date=new Date();
                book.setTime_amanat(String.valueOf(date.getTime()));
            }else if(h==2){
                System.out.println("Enter a name");
                String nm=scanner.next();
                Book book=new Book();
                    Book book1=new Book();
                    book=book1.findBook(nm);
                    if(!book.getBook().equals("")){
                        System.out.println("Books Id:"+book1.getId());
                        System.out.println("Books Name"+book1.getBook());
                        System.out.println("Books Author:"+book1.getAuthor());
                        System.out.println("Books Publisher"+book1.getNasher());
                    }


            }
            else if(h==3){
                add_Book();
            }
            else if(h==4){
                Book book=new Book();
                List<Book>list=book.getAllBooks_All();
                for (int i = 0; i < list.size(); i++) {
                    if(list.get(i).isAmanat()==true){
                        System.out.println("Books Id:"+book.getId());
                        System.out.println("Books Name"+book.getBook());
                        System.out.println("Books Author:"+book.getAuthor());
                        System.out.println("Books Publisher"+book.getNasher());
                    }
                }
            }
            else if(h==5){
                break;
            }
            else {
                System.out.println("Wrong input");
            }
        }

    }

    static void add_Book() throws IOException {
        Book book=new Book();
        Scanner scanner=new Scanner(System.in);
        System.out.println("Enter Identification");
        book.setId((long) scanner.nextInt());
        System.out.println("Enter Book name");
        book.setBook( scanner.next());
        System.out.println("Enter Author name");
        book.setAuthor( scanner.next());
        System.out.println("Enter Publisher name");
        book.setNasher( scanner.next());
        System.out.println("Enter Category");
        book.setDaste( scanner.next());
        System.out.println("Enter Published date");
        book.setDate( scanner.next());
        book.save(book);
        System.out.println("Book was added succesfuly");
    }
    
static void login(){
    Scanner scanner=new Scanner(System.in);
    System.out.println("Enter username");
    String usr=scanner.next();
    System.out.println("Enter password");
    String pass=scanner.next();

    Users users=new Users();
    String s=users.getAll(usr,pass);
    if(s==""){
            System.out.println("Wrong username or Password");
            
    }
    else{
           System.out.println("Logged in succesfully :)");
        current_user=usr;
        current_pass=pass;
        current_mode=s;
       }
    }
   

static void Signin(){
    Scanner scanner=new Scanner(System.in);
    System.out.println("Enter username");
    String usr=scanner.next();
    System.out.println("Enter password");
    String pass=scanner.next();
    System.out.println("Please enter your full name");
    String fullname=scanner.next();
    
    try
    {
        String filename= "users.txt";
        Random random=new Random();
        
        FileWriter fw = new FileWriter(filename,true); //the true will append the new data
        fw.write(random.nextInt()*123+",1"+","+usr+","+pass+","+fullname+"/");//appends the string to the file
        fw.close();
        System.out.println("Signed_in successfuly");
    }
    catch(IOException ioe)
    {
        System.err.println("IOException: " + ioe.getMessage());
    }

}
}
