package models;
import services.BookService;
import java.io.*;
import java.util.*;
public class Book implements BookService {
    String book;
    String author;
    Long id;
    String nasher;
    String date;
    String daste;
    boolean amanat;
    Long id_amanat;
    String time_amanat;
    public String getNasher() {
        return nasher;
    }

    public void setNasher(String nasher) {
        this.nasher = nasher;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getDaste() {
        return daste;
    }

    public void setDaste(String daste) {
        this.daste = daste;
    }

    public boolean isAmanat() {
        return amanat;
    }

    public void setAmanat(boolean amanat) {
        this.amanat = amanat;
    }

    public Long getId_amanat() {
        return id_amanat;
    }

    public void setId_amanat(Long id_amanat) {
        this.id_amanat = id_amanat;
    }

    public String getTime_amanat() {
        return time_amanat;
    }

    public void setTime_amanat(String time_amanat) {
        this.time_amanat = time_amanat;
    }

    public String getBook() {
        return book;
    }

    public void setBook(String book) {
        this.book = book;
    }

    public String getAuthor() {
        return author;
    }

    public void setAuthor(String author) {
        this.author = author;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    @Override
    public void save(Book book) throws IOException {
        try
        {
            String filename= "book.txt";
            FileWriter fw = new FileWriter(filename,true); //the true will append the new data
            fw.write(book.getId()+","+book.getBook()+","+book.getAuthor()+","+book.getNasher()+","+book.getDaste()+"/");//appends the string to the file
            fw.close();
        }
        catch(IOException ioe)
        {
            System.err.println("IOException: " + ioe.getMessage());
        }
    }

    @Override
    public void delete(Long id) throws IOException {
        List<String> list = new ArrayList<>();
        String data = null;
        //get from file
        try {
            File myObj = new File("book.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                data = myReader.nextLine();
                System.out.println(data);
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        //
        String[] splited = data.split("/");
        for (int i = 0; i < splited.length; i++) {
            String[] splited_1 = splited[i].split(",");
            if (id != Long.valueOf(splited_1[0])) {
                list.add(splited[i]);
            }
        }
        //write
        try {
            String filename = "book.txt";
            FileWriter fw = new FileWriter(filename, true); //the true will append the new data
            for (int i = 0; i < list.size(); i++) {
                fw.write(list.get(i) + "/");//appends the string to the file

            }

            fw.close();
        } catch (IOException ioe) {
            System.err.println("IOException: " + ioe.getMessage());
        }
        try {
            String s = null;
            for (int i = 0; i < list.size(); i++) {
                s = list.get(i) + "/";
            }
            BufferedWriter writer = new BufferedWriter(new FileWriter("book.txt"));
            writer.write(s);

            writer.close();
            ////

        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    @Override
    public List<String> getAllBooks() {
        List<String>list=new ArrayList<>();
        String data="";
        try {
            File myObj = new File("book.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                data = myReader.nextLine();
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            String[] splited = data.split("/");
            for (int i = 0; i < splited.length; i++) {
                String[] splited_1 = splited[i].split(",");
                list.add(splited_1[1]);
            }
        }catch (Exception e){
            System.out.println("no books available");
        }


        return list;
    }

    @Override
    public List<Book> getAllBooks_All() {
        List<Book>list=new ArrayList<>();
        String data="";
        try {
            File myObj = new File("book.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                data = myReader.nextLine();
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        try {
            String[] splited = data.split("/");
            for (int i = 0; i < splited.length; i++) {
                String[] splited_1 = splited[i].split(",");
                Book b=new Book();
                b.setId(Long.valueOf(splited_1[0]));
                b.setBook(splited_1[1]);
                b.setAuthor(splited_1[2]);
                b.setNasher(splited_1[3]);
                b.setDaste(splited_1[4]);
                b.setDate(splited_1[5]);
                b.setAmanat(Boolean.parseBoolean(splited_1[6]));
                b.setId_amanat(Long.valueOf(splited_1[7]));
                list.add(b);
            }
        }catch (Exception e){
            System.out.println("no books available");
        }


        return list;
    }

    @Override
    public Book findBook(String name) {
        Book book=new Book();
        String data = null;
        try {
            File myObj = new File("book.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                data = myReader.nextLine();
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }

        try {
            String[] splited = data.split("/");
            for (int i = 0; i < splited.length; i++) {
                String[] splited_1 = splited[i].split(",");
                if (splited_1[1].equals(name)) {
                    book.setId(Long.valueOf(splited_1[0]));
                    book.setBook(splited_1[1]);
                    book.setAuthor(splited_1[2]);
                    book.setNasher(splited_1[3]);
                    book.setDaste(splited_1[4]);
                    book.setDate(splited_1[5]);
                    book.setAmanat(Boolean.parseBoolean(splited_1[6]));
                    book.setId_amanat(Long.valueOf(splited_1[7]));
                    break;
                }
                if(!book.getBook().equals("")){
                    break;
                }
            }
        }catch (Exception e){
            System.out.println("no books found with this name!");
        }

        return book;
    }


}
