package models;

import services.UserService;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class Users implements UserService {
    Long id;
    String username;
    String password;
    String mode;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getMode() {
        return mode;
    }

    public void setMode(String mode) {
        this.mode = mode;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String getAll(String username,String pass) {
        //get from file
        String t="";
        String data = null;
        try {
            File myObj = new File("users.txt");
            Scanner myReader = new Scanner(myObj);
            while (myReader.hasNextLine()) {
                data = myReader.nextLine();
            }
            myReader.close();
        } catch (FileNotFoundException e) {
            System.out.println("An error occurred.");
            e.printStackTrace();
        }
        String[] splited=data.split("/");
        for (int i = 0; i < splited.length; i++) {
            String[] splited_1 = splited[i].split(",");
            if (splited_1[2].equals(username) && splited_1[3].equals(pass)) {
                t=splited_1[1];
                break;
            }
            if(!t.equals("")){
                break;
            }
        }




        //
        return t;
    }








}
